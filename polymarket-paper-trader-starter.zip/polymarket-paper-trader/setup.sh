#!/bin/bash
# Polymarket Paper Trader — Quick Start Script
# Run this in your project directory before starting Claude Code

set -e

echo "🚀 Polymarket Paper Trader — Setup"
echo "=================================="
echo ""

# Check for Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 18+ first."
    exit 1
fi

# Check for Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker not found. Please install Docker Desktop first."
    exit 1
fi

echo "✅ Prerequisites found (Node.js + Docker)"
echo ""

# Install GSD
echo "📦 Installing GSD (Get Shit Done) protocol..."
npx get-shit-done-cc --local

echo ""
echo "✅ GSD installed to ./.claude/"
echo ""

# Create initial directories
mkdir -p data
mkdir -p backend/app
mkdir -p frontend/src

echo "📁 Created project directories"
echo ""

# Create .env.example
cat > .env.example << 'EOF'
# Backend Configuration
POLYMARKET_API_URL=https://gamma-api.polymarket.com
FETCH_INTERVAL_SECONDS=300
STARTING_BALANCE=100.0
DATABASE_PATH=/app/data/trades.db

# Frontend Configuration
VITE_API_URL=http://localhost:8000/api
EOF

echo "📝 Created .env.example"
echo ""

# Create .gitignore
cat > .gitignore << 'EOF'
# Dependencies
node_modules/
__pycache__/
*.pyc
.venv/
venv/

# Environment
.env
.env.local

# Database
data/*.db
data/*.db-journal

# Build outputs
dist/
build/
*.egg-info/

# IDE
.idea/
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# GSD Planning (optional - comment out to track)
# .planning/
EOF

echo "📝 Created .gitignore"
echo ""

echo "=================================="
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Start Claude Code with: claude --dangerously-skip-permissions"
echo "2. Run: /gsd:new-project"
echo "3. Reference POLYMARKET_MEGA_PROMPT.md for specification"
echo ""
echo "Happy building! 🎉"
