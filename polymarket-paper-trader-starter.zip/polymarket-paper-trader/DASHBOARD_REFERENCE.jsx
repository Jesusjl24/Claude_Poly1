import React, { useState, useEffect } from 'react';

// Mock data
const MOCK_OPPORTUNITIES = [
  { id: 1, slug: "will-bitcoin-hit-150k-july-2025", question: "Will Bitcoin hit $150k by July 2025?", category: "crypto", priceYes: 0.42, priceNo: 0.58, volume: 892000, endDate: "2025-07-01", recommendedSide: "YES" },
  { id: 2, slug: "rain-nyc-jan-25", question: "Will it rain in NYC on Jan 25?", category: "weather", priceYes: 0.35, priceNo: 0.65, volume: 45000, endDate: "2025-01-25", recommendedSide: "YES" },
  { id: 3, slug: "eth-flip-btc-2025", question: "Will ETH flip BTC market cap in 2025?", category: "crypto", priceYes: 0.12, priceNo: 0.88, volume: 1250000, endDate: "2025-12-31", recommendedSide: "YES" },
  { id: 4, slug: "super-bowl-chiefs-2025", question: "Super Bowl winner: Chiefs?", category: "sports", priceYes: 0.38, priceNo: 0.62, volume: 3400000, endDate: "2025-02-09", recommendedSide: "YES" },
  { id: 5, slug: "trump-executive-order-jan-20", question: "Trump signs 10+ executive orders on day 1?", category: "politics", priceYes: 0.55, priceNo: 0.45, volume: 780000, endDate: "2025-01-21", recommendedSide: "NO" },
];

const MOCK_POSITIONS = [
  { id: 101, slug: "tesla-500-march", question: "Will Tesla stock hit $500 by March?", side: "YES", entryPrice: 0.45, currentPrice: 0.52, shares: 22, invested: 10.00, currentValue: 11.56, endDate: "2025-03-15", status: "open" },
  { id: 102, slug: "eth-4k-jan", question: "Ethereum above $4k end of Jan?", side: "NO", entryPrice: 0.55, currentPrice: 0.48, shares: 18, invested: 10.00, currentValue: 8.73, endDate: "2025-01-31", status: "open" },
];

const MOCK_HISTORY = [
  { id: 201, slug: "lakers-win-jan-15", question: "Did Lakers win Jan 15 game?", side: "YES", entryPrice: 0.58, exitPrice: 1.00, shares: 17, invested: 10.00, payout: 17.00, profit: 7.00, resolvedAt: "2025-01-16", result: "WIN" },
  { id: 202, slug: "snow-miami-jan-2025", question: "Snow in Miami Jan 2025?", side: "YES", entryPrice: 0.08, exitPrice: 0.00, shares: 125, invested: 10.00, payout: 0, profit: -10.00, resolvedAt: "2025-01-10", result: "LOSS" },
  { id: 203, slug: "fed-rate-cut-jan", question: "Fed cuts rates in January?", side: "NO", entryPrice: 0.40, exitPrice: 1.00, shares: 25, invested: 10.00, payout: 25.00, profit: 15.00, resolvedAt: "2025-01-15", result: "WIN" },
];

const MOCK_LOGS = [
  { timestamp: "2025-01-18 14:32:05", level: "INFO", message: "Bot cycle started" },
  { timestamp: "2025-01-18 14:32:06", level: "INFO", message: "Fetched 10 events from Polymarket API" },
  { timestamp: "2025-01-18 14:32:06", level: "INFO", message: "Filtered to 4 opportunities (categories: crypto, sports | timeframe: ≤7d)" },
  { timestamp: "2025-01-18 14:32:07", level: "INFO", message: "Cycle complete. Next run in 300s" },
  { timestamp: "2025-01-18 14:27:05", level: "WARN", message: "API rate limit approaching (85/100 requests)" },
  { timestamp: "2025-01-18 14:22:06", level: "ERROR", message: "Failed to fetch market slug 'xyz-123': 404 Not Found" },
];

const CATEGORIES = ["crypto", "politics", "sports", "weather", "entertainment"];
const TIMEFRAMES = [
  { id: "daily", label: "Daily (≤24h)", maxDays: 1 },
  { id: "short", label: "Short-term (≤7 days)", maxDays: 7 },
  { id: "monthly", label: "Monthly (≤30 days)", maxDays: 30 },
  { id: "any", label: "Any timeframe", maxDays: null },
];

// Opportunity Card Component with Edit Mode
function OpportunityCard({ op, defaultTradeAmount, cash, onApprove, onReject, polymarketUrl }) {
  const [isEditing, setIsEditing] = useState(false);
  const [selectedSide, setSelectedSide] = useState(op.recommendedSide);
  const [customAmount, setCustomAmount] = useState(defaultTradeAmount);

  useEffect(() => {
    if (!isEditing) {
      setCustomAmount(defaultTradeAmount);
    }
  }, [defaultTradeAmount, isEditing]);

  const currentPrice = selectedSide === "YES" ? op.priceYes : op.priceNo;
  const shares = Math.floor(customAmount / currentPrice);
  const actualCost = shares * currentPrice;

  const handleApprove = () => {
    onApprove(op, selectedSide, customAmount);
    setIsEditing(false);
  };

  return (
    <div className="p-4 hover:bg-gray-750 border-b border-gray-700 last:border-b-0">
      <div className="flex justify-between items-start mb-2">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className={`text-xs px-2 py-0.5 rounded ${
              op.category === 'crypto' ? 'bg-orange-900 text-orange-300' :
              op.category === 'sports' ? 'bg-green-900 text-green-300' :
              op.category === 'politics' ? 'bg-purple-900 text-purple-300' :
              op.category === 'weather' ? 'bg-blue-900 text-blue-300' :
              'bg-gray-700 text-gray-300'
            }`}>{op.category}</span>
            <a 
              href={polymarketUrl(op.slug)} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-xs text-blue-400 hover:text-blue-300 hover:underline"
            >
              View on Polymarket ↗
            </a>
          </div>
          <p className="text-white font-medium">{op.question}</p>
        </div>
        <div className="text-right text-sm">
          <p className="text-gray-400">Ends {op.endDate}</p>
          <p className="text-gray-500">Vol: ${(op.volume / 1000).toFixed(0)}k</p>
        </div>
      </div>
      
      {/* Trade Configuration */}
      <div className="mt-3 bg-gray-750 rounded-lg p-3">
        {/* Side Selection */}
        <div className="flex items-center gap-3 mb-3">
          <span className="text-xs text-gray-500 w-16">Side:</span>
          <div className="flex gap-2">
            <button
              onClick={() => { setSelectedSide("YES"); setIsEditing(true); }}
              className={`px-4 py-2 rounded text-sm font-medium transition-all ${
                selectedSide === 'YES' 
                  ? 'bg-green-600 text-white ring-2 ring-green-400' 
                  : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
              }`}
            >
              YES @ ${op.priceYes.toFixed(2)}
            </button>
            <button
              onClick={() => { setSelectedSide("NO"); setIsEditing(true); }}
              className={`px-4 py-2 rounded text-sm font-medium transition-all ${
                selectedSide === 'NO' 
                  ? 'bg-red-600 text-white ring-2 ring-red-400' 
                  : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
              }`}
            >
              NO @ ${op.priceNo.toFixed(2)}
            </button>
          </div>
          {selectedSide !== op.recommendedSide && (
            <span className="text-xs text-yellow-500">(bot suggested {op.recommendedSide})</span>
          )}
        </div>

        {/* Amount Input */}
        <div className="flex items-center gap-3 mb-3">
          <span className="text-xs text-gray-500 w-16">Amount:</span>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">$</span>
            <input
              type="number"
              value={customAmount}
              onChange={(e) => { setCustomAmount(Math.max(0.01, parseFloat(e.target.value) || 0)); setIsEditing(true); }}
              className="w-20 bg-gray-700 border border-gray-600 rounded px-3 py-1.5 text-sm"
              min="0.01"
              step="1"
            />
            <div className="flex gap-1">
              {[5, 10, 25].map(amt => (
                <button
                  key={amt}
                  onClick={() => { setCustomAmount(amt); setIsEditing(true); }}
                  className={`px-2 py-1 rounded text-xs ${
                    customAmount === amt ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
                  }`}
                >
                  ${amt}
                </button>
              ))}
              <button
                onClick={() => { setCustomAmount(cash); setIsEditing(true); }}
                className="px-2 py-1 rounded text-xs bg-gray-700 text-gray-400 hover:bg-gray-600"
              >
                Max
              </button>
            </div>
          </div>
        </div>

        {/* Calculation Preview */}
        <div className="flex items-center gap-3 mb-3">
          <span className="text-xs text-gray-500 w-16">Preview:</span>
          <div className="flex-1 bg-gray-800 rounded p-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">
                Buy <span className="text-white font-medium">{shares}</span> {selectedSide} shares @ ${currentPrice.toFixed(2)}
              </span>
              <span className="text-white font-medium">${actualCost.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-xs mt-1">
              <span className="text-gray-500">If {selectedSide} wins → payout ${shares.toFixed(2)}</span>
              <span className="text-green-400">+${(shares - actualCost).toFixed(2)} profit</span>
            </div>
          </div>
        </div>

        {/* Compare Both Sides */}
        <details className="mb-3">
          <summary className="text-xs text-blue-400 cursor-pointer hover:text-blue-300">
            Compare both sides
          </summary>
          <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
            <div className={`p-2 rounded ${selectedSide === 'YES' ? 'bg-green-900/30 ring-1 ring-green-600' : 'bg-gray-800'}`}>
              <div className="font-medium text-green-400 mb-1">YES @ ${op.priceYes.toFixed(2)}</div>
              <div className="text-gray-400">
                {Math.floor(customAmount / op.priceYes)} shares<br />
                Potential: ${Math.floor(customAmount / op.priceYes).toFixed(2)}<br />
                Profit: +${(Math.floor(customAmount / op.priceYes) - customAmount).toFixed(2)}
              </div>
            </div>
            <div className={`p-2 rounded ${selectedSide === 'NO' ? 'bg-red-900/30 ring-1 ring-red-600' : 'bg-gray-800'}`}>
              <div className="font-medium text-red-400 mb-1">NO @ ${op.priceNo.toFixed(2)}</div>
              <div className="text-gray-400">
                {Math.floor(customAmount / op.priceNo)} shares<br />
                Potential: ${Math.floor(customAmount / op.priceNo).toFixed(2)}<br />
                Profit: +${(Math.floor(customAmount / op.priceNo) - customAmount).toFixed(2)}
              </div>
            </div>
          </div>
        </details>

        {/* Action Buttons */}
        <div className="flex justify-between items-center">
          <button
            onClick={() => { setSelectedSide(op.recommendedSide); setCustomAmount(defaultTradeAmount); setIsEditing(false); }}
            className="text-xs text-gray-500 hover:text-gray-400"
          >
            Reset to default
          </button>
          <div className="flex gap-2">
            <button
              onClick={() => onReject(op.id)}
              className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded text-sm"
            >
              Skip
            </button>
            <button
              onClick={handleApprove}
              disabled={cash < actualCost || shares < 1}
              className="px-5 py-2 bg-green-600 hover:bg-green-500 disabled:bg-gray-600 disabled:cursor-not-allowed rounded text-sm font-medium"
            >
              ✓ Approve {selectedSide} (${actualCost.toFixed(2)})
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function PolymarketDashboard() {
  // Portfolio state
  const [portfolio, setPortfolio] = useState({ cash: 70.00, startingBalance: 100.00, withdrawn: 0 });
  const [opportunities, setOpportunities] = useState(MOCK_OPPORTUNITIES);
  const [positions, setPositions] = useState(MOCK_POSITIONS);
  const [history, setHistory] = useState(MOCK_HISTORY);
  const [logs, setLogs] = useState(MOCK_LOGS);
  
  // Bot settings state
  const [botRunning, setBotRunning] = useState(true);
  const [fetchingEnabled, setFetchingEnabled] = useState(true);
  const [selectedCategories, setSelectedCategories] = useState(["crypto", "sports"]);
  const [selectedTimeframe, setSelectedTimeframe] = useState("short");
  const [tradeAmount, setTradeAmount] = useState(10);
  const [maxPrice, setMaxPrice] = useState(0.60);
  
  // UI state
  const [activeTab, setActiveTab] = useState("opportunities");
  const [countdown, setCountdown] = useState(300);
  const [showSettings, setShowSettings] = useState(false);
  const [showLogs, setShowLogs] = useState(false);
  const [fundsAmount, setFundsAmount] = useState("");
  const [fundsMode, setFundsMode] = useState(null); // null, 'add', or 'withdraw'

  // Countdown timer - only runs when fetching is enabled
  useEffect(() => {
    if (!botRunning || !fetchingEnabled) return;
    const timer = setInterval(() => {
      setCountdown(prev => prev > 0 ? prev - 1 : 300);
    }, 1000);
    return () => clearInterval(timer);
  }, [botRunning, fetchingEnabled]);

  // Filter opportunities by selected categories
  const filteredOpportunities = opportunities.filter(op => 
    selectedCategories.includes(op.category)
  );

  // Derived data for tabs
  const winningTrades = history.filter(h => h.result === "WIN");
  const losingTrades = history.filter(h => h.result === "LOSS");

  const handleApprove = (opportunity, side, amount) => {
    const price = side === "YES" ? opportunity.priceYes : opportunity.priceNo;
    const shares = Math.floor(amount / price);
    const actualCost = shares * price;
    
    const newPosition = {
      id: Date.now(),
      slug: opportunity.slug,
      question: opportunity.question,
      side: side,
      entryPrice: price,
      currentPrice: price,
      shares: shares,
      invested: actualCost,
      currentValue: actualCost,
      endDate: opportunity.endDate,
      status: "open"
    };
    
    setPositions([...positions, newPosition]);
    setPortfolio(prev => ({ ...prev, cash: prev.cash - actualCost }));
    setOpportunities(opportunities.filter(op => op.id !== opportunity.id));
    addLog("INFO", `Approved trade: ${opportunity.question} (${side} @ $${price.toFixed(2)}, ${shares} shares, $${actualCost.toFixed(2)})`);
  };

  const handleReject = (id) => {
    const op = opportunities.find(o => o.id === id);
    setOpportunities(opportunities.filter(op => op.id !== id));
    addLog("INFO", `Skipped opportunity: ${op?.question}`);
  };

  const addLog = (level, message) => {
    const newLog = {
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      level,
      message
    };
    setLogs(prev => [newLog, ...prev].slice(0, 50));
  };

  const handleFundsAction = () => {
    const amount = parseFloat(fundsAmount);
    if (amount > 0) {
      if (fundsMode === 'add') {
        setPortfolio(prev => ({ ...prev, cash: prev.cash + amount }));
        addLog("INFO", `Deposited $${amount.toFixed(2)} to paper account`);
      } else if (fundsMode === 'withdraw') {
        if (amount <= portfolio.cash) {
          setPortfolio(prev => ({ 
            ...prev, 
            cash: prev.cash - amount,
            withdrawn: prev.withdrawn + amount
          }));
          addLog("INFO", `Withdrew $${amount.toFixed(2)} from paper account (taking profits)`);
        }
      }
      setFundsAmount("");
      setFundsMode(null);
    }
  };

  const toggleCategory = (cat) => {
    setSelectedCategories(prev => 
      prev.includes(cat) 
        ? prev.filter(c => c !== cat)
        : [...prev, cat]
    );
  };

  const toggleBot = () => {
    setBotRunning(prev => !prev);
    addLog(botRunning ? "WARN" : "INFO", botRunning ? "Bot stopped by user" : "Bot started by user");
  };

  const toggleFetching = () => {
    setFetchingEnabled(prev => !prev);
    addLog(fetchingEnabled ? "INFO" : "INFO", fetchingEnabled ? "Fetching paused - bot will continue monitoring positions" : "Fetching resumed");
  };

  const formatTime = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const totalPnL = history.reduce((sum, h) => sum + h.profit, 0);
  const winRate = history.length > 0 
    ? ((winningTrades.length / history.length) * 100).toFixed(0)
    : 0;
  const positionsValue = positions.reduce((s, p) => s + p.currentValue, 0);
  const totalValue = portfolio.cash + positionsValue;

  const polymarketUrl = (slug) => `https://polymarket.com/event/${slug}`;

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-4 md:p-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Polymarket Paper Trader</h1>
          <p className="text-gray-400 text-sm">Educational / Research Mode</p>
        </div>
        
        <div className="flex items-center gap-3 flex-wrap">
          {/* Bot Toggle */}
          <button
            onClick={toggleBot}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              botRunning 
                ? 'bg-green-600 hover:bg-green-500 text-white' 
                : 'bg-red-600 hover:bg-red-500 text-white'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${botRunning ? 'bg-green-300 animate-pulse' : 'bg-red-300'}`}></span>
            {botRunning ? 'Bot Running' : 'Bot Stopped'}
          </button>

          {/* Fetch Toggle */}
          <button
            onClick={toggleFetching}
            disabled={!botRunning}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              !botRunning 
                ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                : fetchingEnabled 
                  ? 'bg-blue-600 hover:bg-blue-500 text-white' 
                  : 'bg-gray-600 hover:bg-gray-500 text-gray-300'
            }`}
          >
            {fetchingEnabled ? (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Fetching
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Paused
              </>
            )}
          </button>
          
          {/* Next Run Timer */}
          <div className="text-right bg-gray-800 px-4 py-2 rounded-lg">
            <p className="text-xs text-gray-500">Next fetch</p>
            <p className={`text-lg font-mono ${botRunning && fetchingEnabled ? 'text-blue-400' : 'text-gray-500'}`}>
              {botRunning && fetchingEnabled ? formatTime(countdown) : '--:--'}
            </p>
          </div>
          
          {/* Settings Toggle */}
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-2 rounded-lg ${showSettings ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'}`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </button>
        </div>
      </div>

      {/* Bot Settings Panel (Collapsible) */}
      {showSettings && (
        <div className="bg-gray-800 rounded-lg p-4 mb-6 border border-gray-700">
          <h3 className="text-sm font-semibold text-gray-300 mb-4 uppercase tracking-wide">Bot Configuration</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Categories */}
            <div>
              <label className="block text-xs text-gray-500 mb-2">Search Categories</label>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map(cat => (
                  <button
                    key={cat}
                    onClick={() => toggleCategory(cat)}
                    className={`px-3 py-1 rounded text-sm capitalize transition-colors ${
                      selectedCategories.includes(cat) 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Timeframe */}
            <div>
              <label className="block text-xs text-gray-500 mb-2">Opportunity Timeframe</label>
              <select
                value={selectedTimeframe}
                onChange={(e) => setSelectedTimeframe(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm"
              >
                {TIMEFRAMES.map(tf => (
                  <option key={tf.id} value={tf.id}>{tf.label}</option>
                ))}
              </select>
            </div>
            
            {/* Trade Amount */}
            <div>
              <label className="block text-xs text-gray-500 mb-2">Default Trade Amount</label>
              <div className="flex items-center gap-2">
                <span className="text-gray-400">$</span>
                <input
                  type="number"
                  value={tradeAmount}
                  onChange={(e) => setTradeAmount(Math.max(1, parseFloat(e.target.value) || 0))}
                  className="w-20 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm"
                  min="1"
                  step="1"
                />
                <span className="text-xs text-gray-500">
                  ({Math.floor(portfolio.cash / tradeAmount)} trades possible)
                </span>
              </div>
            </div>
            
            {/* Max Price */}
            <div>
              <label className="block text-xs text-gray-500 mb-2">Max Entry Price</label>
              <div className="flex items-center gap-2">
                <span className="text-gray-400">≤ $</span>
                <input
                  type="number"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Math.min(0.99, Math.max(0.01, parseFloat(e.target.value) || 0.5)))}
                  className="w-20 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm"
                  min="0.01"
                  max="0.99"
                  step="0.05"
                />
                <span className="text-xs text-gray-500">
                  (filters YES or NO below this)
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Portfolio Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-6">
        <div className="bg-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500 uppercase">Available Cash</p>
          <p className="text-xl font-bold text-green-400">${portfolio.cash.toFixed(2)}</p>
        </div>
        <div className="bg-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500 uppercase">In Positions</p>
          <p className="text-xl font-bold text-blue-400">${positionsValue.toFixed(2)}</p>
        </div>
        <div className="bg-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500 uppercase">Total Value</p>
          <p className="text-xl font-bold text-white">${totalValue.toFixed(2)}</p>
        </div>
        <div className="bg-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500 uppercase">Realized P&L</p>
          <p className={`text-xl font-bold ${totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {totalPnL >= 0 ? '+' : ''}{totalPnL.toFixed(2)}
          </p>
        </div>
        <div className="bg-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500 uppercase">Withdrawn</p>
          <p className="text-xl font-bold text-yellow-400">${portfolio.withdrawn.toFixed(2)}</p>
        </div>
        <div className="bg-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500 uppercase">Win Rate</p>
          <p className="text-xl font-bold text-purple-400">{winRate}%</p>
          <p className="text-xs text-gray-500">{winningTrades.length}W / {losingTrades.length}L</p>
        </div>
        
        {/* Add/Withdraw Funds */}
        <div className="bg-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500 uppercase mb-2">Manage Funds</p>
          {fundsMode ? (
            <div className="space-y-2">
              <div className="flex gap-1">
                <span className="text-gray-400 text-sm">$</span>
                <input
                  type="number"
                  value={fundsAmount}
                  onChange={(e) => setFundsAmount(e.target.value)}
                  placeholder="Amount"
                  className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm"
                  autoFocus
                />
              </div>
              <div className="flex gap-1">
                <button 
                  onClick={handleFundsAction} 
                  disabled={fundsMode === 'withdraw' && parseFloat(fundsAmount) > portfolio.cash}
                  className={`flex-1 px-2 py-1 rounded text-xs font-medium ${
                    fundsMode === 'add' 
                      ? 'bg-green-600 hover:bg-green-500' 
                      : 'bg-yellow-600 hover:bg-yellow-500 disabled:bg-gray-600 disabled:cursor-not-allowed'
                  }`}
                >
                  {fundsMode === 'add' ? 'Deposit' : 'Withdraw'}
                </button>
                <button 
                  onClick={() => { setFundsMode(null); setFundsAmount(""); }} 
                  className="px-2 py-1 bg-gray-600 hover:bg-gray-500 rounded text-xs"
                >
                  ×
                </button>
              </div>
              {fundsMode === 'withdraw' && parseFloat(fundsAmount) > portfolio.cash && (
                <p className="text-xs text-red-400">Exceeds available cash</p>
              )}
            </div>
          ) : (
            <div className="flex gap-1">
              <button
                onClick={() => setFundsMode('add')}
                className="flex-1 px-2 py-1.5 bg-green-700 hover:bg-green-600 rounded text-xs font-medium"
              >
                + Add
              </button>
              <button
                onClick={() => setFundsMode('withdraw')}
                className="flex-1 px-2 py-1.5 bg-yellow-700 hover:bg-yellow-600 rounded text-xs font-medium"
              >
                − Withdraw
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Active Bot Filters Display */}
      <div className="flex items-center gap-2 mb-4 text-sm flex-wrap">
        <span className="text-gray-500">Bot searching:</span>
        {selectedCategories.map(cat => (
          <span key={cat} className="px-2 py-0.5 bg-blue-900 text-blue-300 rounded text-xs capitalize">{cat}</span>
        ))}
        <span className="text-gray-600">|</span>
        <span className="text-gray-400">{TIMEFRAMES.find(t => t.id === selectedTimeframe)?.label}</span>
        <span className="text-gray-600">|</span>
        <span className="text-gray-400">≤ ${maxPrice.toFixed(2)}</span>
        {!fetchingEnabled && (
          <>
            <span className="text-gray-600">|</span>
            <span className="px-2 py-0.5 bg-yellow-900 text-yellow-300 rounded text-xs">Fetching paused</span>
          </>
        )}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-700 mb-4 overflow-x-auto">
        {[
          { id: "opportunities", label: "Pending Approval", count: filteredOpportunities.length },
          { id: "positions", label: "Open Positions", count: positions.length },
          { id: "history", label: "All History", count: history.length },
          { id: "wins", label: "Winning Trades", count: winningTrades.length, color: "text-green-400" },
          { id: "losses", label: "Losing Trades", count: losingTrades.length, color: "text-red-400" },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px whitespace-nowrap ${
              activeTab === tab.id 
                ? 'border-blue-500 text-blue-400' 
                : 'border-transparent text-gray-400 hover:text-gray-300'
            }`}
          >
            {tab.label} (<span className={tab.color || ''}>{tab.count}</span>)
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="bg-gray-800 rounded-lg overflow-hidden mb-6">
        {activeTab === "opportunities" && (
          <div>
            {filteredOpportunities.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                No opportunities matching criteria.
                {!botRunning ? ' Start the bot to fetch opportunities.' : 
                 !fetchingEnabled ? ' Resume fetching to get new opportunities.' :
                 ` Bot will fetch more in ${formatTime(countdown)}.`}
              </div>
            ) : (
              filteredOpportunities.map(op => (
                <OpportunityCard
                  key={op.id}
                  op={op}
                  defaultTradeAmount={tradeAmount}
                  cash={portfolio.cash}
                  onApprove={handleApprove}
                  onReject={handleReject}
                  polymarketUrl={polymarketUrl}
                />
              ))
            )}
          </div>
        )}

        {activeTab === "positions" && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-750 text-gray-400 text-left">
                <tr>
                  <th className="p-3">Market</th>
                  <th className="p-3">Link</th>
                  <th className="p-3">Side</th>
                  <th className="p-3">Entry</th>
                  <th className="p-3">Current</th>
                  <th className="p-3">Shares</th>
                  <th className="p-3">Value</th>
                  <th className="p-3">P&L</th>
                  <th className="p-3">Resolves</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {positions.length === 0 ? (
                  <tr><td colSpan={9} className="p-8 text-center text-gray-500">No open positions</td></tr>
                ) : positions.map(pos => {
                  const pnl = pos.currentValue - pos.invested;
                  return (
                    <tr key={pos.id} className="hover:bg-gray-750">
                      <td className="p-3 max-w-xs truncate">{pos.question}</td>
                      <td className="p-3">
                        <a href={polymarketUrl(pos.slug)} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline text-xs">
                          View ↗
                        </a>
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-xs ${pos.side === 'YES' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'}`}>
                          {pos.side}
                        </span>
                      </td>
                      <td className="p-3">${pos.entryPrice.toFixed(2)}</td>
                      <td className="p-3">${pos.currentPrice.toFixed(2)}</td>
                      <td className="p-3">{pos.shares}</td>
                      <td className="p-3">${pos.currentValue.toFixed(2)}</td>
                      <td className={`p-3 ${pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {pnl >= 0 ? '+' : ''}{pnl.toFixed(2)}
                      </td>
                      <td className="p-3 text-gray-400">{pos.endDate}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {(activeTab === "history" || activeTab === "wins" || activeTab === "losses") && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-750 text-gray-400 text-left">
                <tr>
                  <th className="p-3">Market</th>
                  <th className="p-3">Link</th>
                  <th className="p-3">Side</th>
                  <th className="p-3">Entry</th>
                  <th className="p-3">Exit</th>
                  <th className="p-3">Invested</th>
                  <th className="p-3">Payout</th>
                  <th className="p-3">Result</th>
                  <th className="p-3">Resolved</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {(activeTab === "wins" ? winningTrades : activeTab === "losses" ? losingTrades : history).length === 0 ? (
                  <tr><td colSpan={9} className="p-8 text-center text-gray-500">No trades yet</td></tr>
                ) : (activeTab === "wins" ? winningTrades : activeTab === "losses" ? losingTrades : history).map(h => (
                  <tr key={h.id} className="hover:bg-gray-750">
                    <td className="p-3 max-w-xs truncate">{h.question}</td>
                    <td className="p-3">
                      <a href={polymarketUrl(h.slug)} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline text-xs">
                        View ↗
                      </a>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-xs ${h.side === 'YES' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'}`}>
                        {h.side}
                      </span>
                    </td>
                    <td className="p-3">${h.entryPrice.toFixed(2)}</td>
                    <td className="p-3">${h.exitPrice.toFixed(2)}</td>
                    <td className="p-3">${h.invested.toFixed(2)}</td>
                    <td className="p-3">${h.payout.toFixed(2)}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${h.result === 'WIN' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}>
                        {h.result} {h.profit >= 0 ? '+' : ''}{h.profit.toFixed(2)}
                      </span>
                    </td>
                    <td className="p-3 text-gray-400">{h.resolvedAt}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Debug / Error Logs Panel */}
      <div className="bg-gray-800 rounded-lg overflow-hidden">
        <button
          onClick={() => setShowLogs(!showLogs)}
          className="w-full flex items-center justify-between p-3 hover:bg-gray-750 text-left"
        >
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-gray-300">Debug Logs</span>
            {logs.some(l => l.level === "ERROR") && (
              <span className="px-2 py-0.5 bg-red-900 text-red-300 rounded text-xs">
                {logs.filter(l => l.level === "ERROR").length} errors
              </span>
            )}
          </div>
          <svg className={`w-4 h-4 text-gray-400 transition-transform ${showLogs ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        
        {showLogs && (
          <div className="border-t border-gray-700 max-h-64 overflow-y-auto">
            <div className="p-2 space-y-1 font-mono text-xs">
              {logs.map((log, i) => (
                <div key={i} className={`flex gap-2 px-2 py-1 rounded ${
                  log.level === 'ERROR' ? 'bg-red-900/30 text-red-300' :
                  log.level === 'WARN' ? 'bg-yellow-900/30 text-yellow-300' :
                  'text-gray-400'
                }`}>
                  <span className="text-gray-600 shrink-0">{log.timestamp}</span>
                  <span className={`shrink-0 w-12 ${
                    log.level === 'ERROR' ? 'text-red-400' :
                    log.level === 'WARN' ? 'text-yellow-400' :
                    'text-gray-500'
                  }`}>[{log.level}]</span>
                  <span>{log.message}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="mt-6 text-center text-xs text-gray-600">
        Paper Trading Mode • No real money at risk • For educational purposes only
      </div>
    </div>
  );
}
